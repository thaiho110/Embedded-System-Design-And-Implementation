#include <stdio.h>
#include "NUC100Series.h"

#define RECEIVE_SIZE 62

void Clk_Config(void);
void UART0_Config(void);
void UART0_send(uint8_t data);
void UART02_IRQHandler(void);

volatile uint8_t received_byte;
volatile _Bool UART02_IRQ_flag = FALSE;
volatile char tmp;

int main(void) {
	PD12 = 0;
	GPIO_SetMode(PC, BIT12, GPIO_PMD_OUTPUT); 
	GPIO_SetMode(PC, BIT13, GPIO_PMD_OUTPUT); 
	GPIO_SetMode(PC, BIT14, GPIO_PMD_OUTPUT); 
	Clk_Config();
	UART0_Config();
	while(1){	
		if (UART02_IRQ_flag){
			PC->DOUT ^= (1 << 13);
			UART0_send(received_byte); // send back data
			UART02_IRQ_flag = FALSE;
		}
	}
}

void Clk_Config(void) {
	SYS_UnlockReg();
	
	//always turn on HXT clk to avoid error
	// on HXT clk (12MHz)
	CLK->PWRCON |= (1ul<<0);
	while(!(CLK->CLKSTATUS & (1<<0))); // wait to stable
	
	// on 22.1184 MHz internal clk
	CLK->PWRCON |= (1<<2);
	while(!(CLK->CLKSTATUS & (1<<4))); 
	
	//PLL configuration starts
	CLK->PLLCON &= ~(1ul<<19); //0: PLL input is HXT 12MHz (default). 1: PLL input is HIRC 22MHz
	CLK->PLLCON &= ~(1ul<<16); //0: PLL in normal mode. 1: PLL in power-down mode (default)
	CLK->PLLCON &= (~(0x01FFul << 0));
	CLK->PLLCON |= 48; //frequency: 50 MHz
	CLK->PLLCON &= ~(1ul<<18); //0: enable PLL clock out. 1: disable PLL clock (default)
	while(!(CLK->CLKSTATUS & (1ul << 2)));
	//PLL configuration ends
	
	// select HXT for CPU clock
	CLK->CLKSEL0 &= ~(0x7ul<<0);
	CLK->CLKSEL0 |= (0x02ul << 0);
	CLK->PWRCON &= ~(1ul<<7);
	
	//UART clk (22.1184 MHz)
	CLK->CLKSEL1 |= (0x3ul<<24); // set UART use interna 22.1184 MMz clk
	CLK->CLKDIV &= ~(0xFul<<8); // UART clk = UART clk source/(0+1)
	CLK->APBCLK |= (1<<16); // enable UART0
	
	SYS_LockReg();
}

void UART0_Config(void) {
	// UART0 Tx pin config
	GPIO_SetMode(PB, BIT0, GPIO_MODE_INPUT);
	GPIO_SetMode(PB, BIT1, GPIO_MODE_OUTPUT);
	SYS->GPB_MFP |= (SYS_GPB_MFP_PB0_UART0_RXD | SYS_GPB_MFP_PB1_UART0_TXD); // PORTB0 as UART0 Rx & PORTB1 as UART0 Tx	
	
	// UART0 operation config
	UART0->LCR |= (3ul<<0); // set word length 8-bit
	UART0->LCR &= ~(1ul<<2); // set 1-stop bit
	UART0->LCR &= ~(1ul<<3); // no parity bit
	UART0->FCR |= (1<<1); // reset Rx pointer
	UART0->FCR |= (1<<2); // reset Tx pointer
	UART0->FCR &= ~(0x0Ful<<16); // set auto-trigger level 1 byte
	
	// set Baud rate mode 0 // pg 364
	// Baud rate = 115200 bps
	UART0->BAUD &= ~(1ul<<28); // DIV_X_ONE = 0
	UART0->BAUD &= ~(1ul<<29); // DIV_X_ENF disable
	UART0->BAUD &= ~(0xFFFFul<<0);
	UART0->BAUD |= 10; // set BRD
	
	//enable UART02 interrupt
	UART0->IER |= (1 << 0); // Enable RDA interrupt
	NVIC->ISER[0] |= (1 << 12); // Enable UART0 interrupt
	NVIC->IP[3] &= ~(3ul << 6); // Set priority to 0
}

void UART0_send(uint8_t data){
	while(UART0->FSR & (0x01 << 23)); //wait until TX FIFO is not full
	UART0->DATA = data;
	if (data == '\n')
		{
		while(UART0->FSR & (0x01 << 23));
		UART0->DATA = '\r'; 
		return;
		}
}

void UART02_IRQHandler(void){
	UART02_IRQ_flag = TRUE;
	received_byte = UART0->RBR;
}